interface IComplexe {
    double reelle();
    double imaginaire();
}