import java.awt.Graphics;

public enum Alignement{
  CENTRE, COINSUPGAUCHE, COINSUPDROIT, COININFGAUCHE, COININFDROIT;
}
